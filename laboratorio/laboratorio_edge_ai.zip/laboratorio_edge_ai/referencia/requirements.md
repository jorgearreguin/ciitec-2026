# Documento de requisitos: alertas de distracción y somnolencia del DMS

## Introducción

Requisito original del cliente: «El sistema debe detectar si el conductor está distraído y avisarle de inmediato».

Así no se puede programar ni probar: «distraído» e «inmediato» no tienen números. Este documento lo convierte en requisitos EARS verificables. Cada requisito lleva su ID (REQ-NN) y su origen: ADDW (reglamento europeo), Cliente o SUPUESTO (pendiente de confirmar).

Es la versión de referencia de la implementación del laboratorio (`dms_logic.py` y `test_dms_logic.py`). Sirve para comparar lo que genere Kiro a partir de la frase vaga.

## Requisitos

### Requisito 1: alerta de distracción según la velocidad

**Historia de usuario:** Como conductor, quiero que el auto me avise si dejo de ver el camino, para no chocar por una distracción.

#### Criterios de aceptación

- **REQ-01** (Origen: ADDW) MIENTRAS la velocidad sea de 50 km/h o más, CUANDO la mirada esté fuera del camino durante 3.5 s o más, EL DMS DEBE emitir una alerta de distracción.
- **REQ-02** (Origen: ADDW) MIENTRAS la velocidad sea de 20 km/h o más y menor de 50 km/h, CUANDO la mirada esté fuera del camino durante 6 s o más, EL DMS DEBE emitir una alerta de distracción.
- **REQ-03** (Origen: SUPUESTO) MIENTRAS la velocidad sea menor de 20 km/h, EL DMS NO DEBE emitir alertas de distracción ni de somnolencia.
- **REQ-06** (Origen: SUPUESTO) CUANDO la mirada regrese al camino, EL DMS DEBE reiniciar el conteo de distracción.

### Requisito 2: alerta de somnolencia

**Historia de usuario:** Como conductor, quiero que el auto me avise si cierro los ojos, para no quedarme dormido al volante.

#### Criterios de aceptación

- **REQ-04** (Origen: SUPUESTO) MIENTRAS la velocidad sea de 20 km/h o más, CUANDO los ojos estén cerrados durante 2 s o más, EL DMS DEBE emitir una alerta de somnolencia.
- **REQ-07** (Origen: SUPUESTO) SI se cumplen a la vez las condiciones de somnolencia y de distracción, ENTONCES EL DMS DEBE emitir la alerta de somnolencia.

### Requisito 3: disponibilidad del monitoreo

**Historia de usuario:** Como conductor, quiero saber cuándo el sistema no me está monitoreando, para no confiar en él sin razón.

#### Criterios de aceptación

- **REQ-05** (Origen: SUPUESTO) SI el rostro no es visible durante 2 s o más, ENTONCES EL DMS DEBE indicar que el monitoreo no está disponible.

## Preguntas para el cliente

Cada SUPUESTO se confirma antes de implementarlo en un producto real:

1. Debajo de 20 km/h la regla no obliga a alertar: ¿se apagan las alertas (REQ-03) o se mantienen?
2. ¿Qué tiempo de ojos cerrados dispara la alerta de somnolencia? Los 2 s de REQ-04 son de demostración.
3. ¿Cuánto tiempo sin rostro antes de avisar que el monitoreo no está disponible? Los 2 s de REQ-05 son de demostración.
4. ¿Qué alerta gana si hay somnolencia y distracción a la vez (REQ-07)? ¿Y si hay otra alerta del auto, por ejemplo de colisión?
5. ¿Una mirada breve al camino reinicia el conteo (REQ-06) o hace falta un tiempo mínimo de mirada al frente?

Fuente de REQ-01 y REQ-02: requisitos ADDW del Reglamento General de Seguridad de la UE, citados en la guía de estudio. Material didáctico: no está validado para uso en un vehículo.
