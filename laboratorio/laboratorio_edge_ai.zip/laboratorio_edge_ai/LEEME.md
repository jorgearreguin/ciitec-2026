# Laboratorio de Edge AI: DMS y cuantización

Material didáctico para la conferencia del 11 de noviembre. No está validado para uso en un vehículo.
Los pasos completos, con lo que debes observar en cada uno, están en la guía de estudio, sección «Laboratorio en tu laptop».

## Archivos

| Archivo | Qué hace |
| --- | --- |
| `dms_logic.py` | Lógica de decisión determinista del DMS, con sus requisitos EARS |
| `test_dms_logic.py` | 23 pruebas de valores límite de esa lógica |
| `dms_lab.py` | DMS con la cámara web: MediaPipe, apertura de ojos, pose de la cabeza, alertas y latencias |
| `bench_quant.py` | MobileNetV2 en FP32, FP16 e INT8, en CPU y GPU, con latencia p50 y p99 |
| `requirements.txt` | Paquetes de Python |
| `trazabilidad.py` | Corre las pruebas y escribe la matriz requisito → código → prueba → resultado |
| `referencia/requirements.md` | Los requisitos REQ-01 a REQ-07 en el formato de una spec de Kiro, con su origen |
| `kiro_inicio/` | Punto de partida para Kiro: reglas de steering y la frase vaga del cliente |
| `KIRO.md` | Paso a paso: de la frase vaga a la matriz de trazabilidad con Kiro |

## Instalación (PowerShell)

Descomprime en `C:\lab_edge_ai`, una ruta sin acentos ni espacios.

```
cd C:\lab_edge_ai
py -3.12 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
```

Si PowerShell no deja activar el entorno: `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned` y vuelve a activarlo.

Verifica la GPU:

```
nvidia-smi
python -c "import onnxruntime as ort; ort.preload_dlls(); print(ort.get_available_providers())"
```

En `nvidia-smi`, «CUDA Version» debe ser 13.0 o mayor; si es menor, actualiza el controlador de NVIDIA. En la segunda línea debe aparecer `CUDAExecutionProvider`.

## Comandos

```
python -m unittest test_dms_logic -v
python trazabilidad.py
python dms_lab.py --grabar prueba
python dms_lab.py --video prueba_crudo.mp4 --sin-ventana
python bench_quant.py --imagenes C:\lab_edge_ai\fotos
python bench_quant.py --imagenes C:\lab_edge_ai\fotos --lote 16
```

Teclas de `dms_lab.py`: 0, 1, 2 y 3 cambian la velocidad simulada a 0, 10, 30 y 80 km/h; c recalibra; q o Esc salen.

## Si algo falla

- La cámara no abre: cierra Teams, Zoom o la app Cámara y prueba `--camara 1`.
- No aparece `CUDAExecutionProvider`, o el banco dice que la sesión «cayó a la CPU»: actualiza el controlador de NVIDIA y ejecuta `pip install --force-reinstall "onnxruntime-gpu[cuda,cudnn]"`. Sin GPU, el banco mide solo la CPU.
- No descarga un modelo: las direcciones de descarga están al inicio de `dms_lab.py` y `bench_quant.py`; bájalo a mano y déjalo en esta carpeta.
