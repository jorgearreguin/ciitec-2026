"""Pruebas de valores limite de la logica del DMS (ver requisitos en dms_logic.py).

Ejecuta:  python -m unittest test_dms_logic -v

Cada prueba nombra el requisito que verifica. La pareja "justo debajo" y "en el limite"
es la idea central: un error de < contra <= solo aparece en el valor exacto.
"""

import unittest

from dms_logic import Alerta, LogicaDMS, umbral_distraccion_ms

PASO_MS = 10  # un evento cada 10 ms


def simular(eventos, logica=None):
    """Aplica eventos (t_ms, velocidad, rostro, mirada_fuera, ojos_cerrados) y devuelve las alertas."""
    logica = logica or LogicaDMS()
    return [logica.actualizar(*e) for e in eventos]


def condicion(velocidad, duracion_ms, rostro=True, fuera=False, cerrados=False, inicio_ms=0):
    """Eventos cada 10 ms desde inicio_ms hasta inicio_ms + duracion_ms, ambos incluidos."""
    return [(t, velocidad, rostro, fuera, cerrados)
            for t in range(inicio_ms, inicio_ms + duracion_ms + 1, PASO_MS)]


class PruebasUmbral(unittest.TestCase):
    def test_req03_debajo_de_20_kmh_sin_umbral(self):
        self.assertIsNone(umbral_distraccion_ms(19.99))

    def test_req02_en_20_kmh_umbral_de_6_s(self):
        self.assertEqual(umbral_distraccion_ms(20.0), 6000)

    def test_req02_justo_debajo_de_50_kmh_umbral_de_6_s(self):
        self.assertEqual(umbral_distraccion_ms(49.99), 6000)

    def test_req01_en_50_kmh_umbral_de_3_5_s(self):
        self.assertEqual(umbral_distraccion_ms(50.0), 3500)

    def test_req01_a_130_kmh_umbral_de_3_5_s(self):
        self.assertEqual(umbral_distraccion_ms(130.0), 3500)


class PruebasDistraccion(unittest.TestCase):
    def test_req01_80_kmh_3_49_s_sin_alerta(self):
        self.assertEqual(simular(condicion(80, 3490, fuera=True))[-1], Alerta.NINGUNA)

    def test_req01_80_kmh_3_50_s_alerta(self):
        self.assertEqual(simular(condicion(80, 3500, fuera=True))[-1], Alerta.DISTRACCION)

    def test_req01_50_kmh_3_50_s_alerta(self):
        self.assertEqual(simular(condicion(50, 3500, fuera=True))[-1], Alerta.DISTRACCION)

    def test_req02_49_9_kmh_3_50_s_sin_alerta(self):
        self.assertEqual(simular(condicion(49.9, 3500, fuera=True))[-1], Alerta.NINGUNA)

    def test_req02_30_kmh_5_99_s_sin_alerta(self):
        self.assertEqual(simular(condicion(30, 5990, fuera=True))[-1], Alerta.NINGUNA)

    def test_req02_30_kmh_6_00_s_alerta(self):
        self.assertEqual(simular(condicion(30, 6000, fuera=True))[-1], Alerta.DISTRACCION)

    def test_req02_20_kmh_6_00_s_alerta(self):
        self.assertEqual(simular(condicion(20, 6000, fuera=True))[-1], Alerta.DISTRACCION)

    def test_req03_19_9_kmh_10_s_sin_alerta(self):
        self.assertEqual(simular(condicion(19.9, 10000, fuera=True))[-1], Alerta.NINGUNA)

    def test_req06_mirar_al_camino_reinicia_el_conteo(self):
        eventos = (condicion(80, 3000, fuera=True)
                   + condicion(80, 0, fuera=False, inicio_ms=3010)
                   + condicion(80, 3490, fuera=True, inicio_ms=3020))
        self.assertEqual(simular(eventos)[-1], Alerta.NINGUNA)
        eventos += [(3020 + 3500, 80, True, True, False)]
        self.assertEqual(simular(eventos)[-1], Alerta.DISTRACCION)


class PruebasSomnolencia(unittest.TestCase):
    def test_req04_80_kmh_1_99_s_ojos_cerrados_sin_alerta(self):
        self.assertEqual(simular(condicion(80, 1990, cerrados=True))[-1], Alerta.NINGUNA)

    def test_req04_80_kmh_2_00_s_ojos_cerrados_alerta(self):
        self.assertEqual(simular(condicion(80, 2000, cerrados=True))[-1], Alerta.SOMNOLENCIA)

    def test_req03_19_9_kmh_ojos_cerrados_sin_alerta(self):
        self.assertEqual(simular(condicion(19.9, 5000, cerrados=True))[-1], Alerta.NINGUNA)

    def test_req07_somnolencia_tiene_prioridad(self):
        eventos = condicion(80, 3500, fuera=True, cerrados=True)
        self.assertEqual(simular(eventos)[-1], Alerta.SOMNOLENCIA)


class PruebasDisponibilidad(unittest.TestCase):
    def test_req05_sin_rostro_1_99_s_sin_aviso(self):
        self.assertEqual(simular(condicion(0, 1990, rostro=False))[-1], Alerta.NINGUNA)

    def test_req05_sin_rostro_2_00_s_no_disponible(self):
        self.assertEqual(simular(condicion(0, 2000, rostro=False))[-1], Alerta.NO_DISPONIBLE)

    def test_req05_aplica_a_cualquier_velocidad(self):
        self.assertEqual(simular(condicion(80, 2000, rostro=False))[-1], Alerta.NO_DISPONIBLE)

    def test_req05_al_volver_el_rostro_se_quita_el_aviso(self):
        eventos = condicion(80, 2500, rostro=False) + [(2510, 80, True, False, False)]
        self.assertEqual(simular(eventos)[-1], Alerta.NINGUNA)


class PruebasDeterminismo(unittest.TestCase):
    def test_mismas_entradas_mismas_salidas(self):
        eventos = (condicion(80, 4000, fuera=True)
                   + condicion(30, 3000, cerrados=True, inicio_ms=4010)
                   + condicion(80, 2500, rostro=False, inicio_ms=7020))
        self.assertEqual(simular(eventos), simular(eventos))


if __name__ == "__main__":
    unittest.main(verbosity=2)
