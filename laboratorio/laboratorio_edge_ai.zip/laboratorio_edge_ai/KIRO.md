# Del requisito vago a la evidencia, con Kiro

Kiro hace la parte de la especificación: requisitos en EARS, diseño, tareas y código. Las reglas de `.kiro/steering/trazabilidad.md` obligan a que cada pieza lleve el mismo ID REQ-NN. `trazabilidad.py` cierra el hilo: ejecuta las pruebas y escribe la matriz que sirve como evidencia.

| Eslabón | Dónde vive | Cómo se marca |
| --- | --- | --- |
| Regla | `.kiro/steering/product.md` | ADDW: 6 s desde 20 km/h, 3.5 s desde 50 km/h |
| Requisito | `.kiro/specs/<nombre>/requirements.md` | `- **REQ-01** (Origen: ADDW) MIENTRAS …, EL DMS DEBE …` |
| Diseño | `design.md` | `Cubre: REQ-01, REQ-02` |
| Tarea | `tasks.md` | `_Requisitos: REQ-01_` |
| Código | `*.py` | comentario `# REQ-01` |
| Prueba | `test_*.py` | `test_req01_…` o `Verifica: REQ-01` en el docstring |
| Evidencia | `matriz_trazabilidad.md` | la genera `python trazabilidad.py` |

Es la misma cadena de la lámina de trazabilidad: regla → requisito de sistema → requisito de software → código → prueba → reporte.

## 1. Mira primero la matriz de la implementación de referencia

En esta carpeta:

```
python trazabilidad.py
```

Lee `referencia/requirements.md`, busca los `# REQ-NN` de `dms_logic.py`, corre las 23 pruebas y escribe `matriz_trazabilidad.md`. Vas a ver un hueco a propósito: la prueba `test_mismas_entradas_mismas_salidas` no tiene requisito. Es el tipo de hueco que la herramienta encuentra sola. Para cerrarlo, agrega un REQ-08 de determinismo o documenta por qué esa prueba no lo necesita.

Si quieres ver cómo se ve una falla, cambia en `dms_logic.py` el `>=` de la línea `t_ms - self._inicio_fuera >= umbral` por `>` y vuelve a correr el script: REQ-01, REQ-02 y REQ-06 aparecen con pruebas que no pasan. Regresa el `>=` al terminar.

## 2. Prepara el espacio de Kiro

1. Copia la carpeta `kiro_inicio` a otro lugar, por ejemplo `C:\dms_kiro`. Usa una carpeta aparte para que Kiro no reutilice el código de referencia.
2. En Kiro, File → Open Folder, y elige `kiro_inicio` misma: en la raíz del explorador deben verse `.kiro`, `REQUISITO_DEL_CLIENTE.md` y `trazabilidad.py`. Si abres la carpeta de arriba, Kiro no ve las reglas.
3. Si aparece el aviso de Restricted Mode, elige Trust; si no, el agente y la terminal quedan limitados.
4. En el panel del fantasma, sección Agent Steering, en Workspace deben aparecer `product`, `tech` y `trazabilidad`.

## 3. Crea la spec desde la frase vaga

1. Haz clic en Create New Spec y escribe solo la frase de `REQUISITO_DEL_CLIENTE.md`.
2. Kiro pregunta el tipo: elige Build a Feature. Luego, por dónde empezar: Requirements. No uses Quick Spec, que genera todo sin detenerse a revisar, y deja Autopilot apagado para aprobar cada cambio.
3. Cuando aparezca `requirements.md`, usa Analyze Requirements. Kiro revisa los títulos en inglés (Glossary, Requirement, Acceptance Criteria); si avisa que falta una sección, cambia el título y deja el contenido en español.
4. Revisa `requirements.md` tú mismo, aunque el análisis diga que no hay ambigüedades:
    - **Los números:** REQ-01 = 3.5 s desde 50 km/h y REQ-02 = 6 s de 20 a menos de 50 km/h, con origen ADDW y un solo rango por criterio.
    - **EARS:** MIENTRAS para el estado (la velocidad) y CUANDO para el evento (la mirada).
    - **Los tiempos:** que nada alerte con un solo cuadro; por ejemplo, el rostro no visible necesita un tiempo mínimo.
    - **Lo que no es de la lógica** (pantalla, sonido, privacidad): sepáralo con IDs SIS-NN para que la matriz cuente solo lo que implementa el módulo.
    - Compáralo con `referencia/requirements.md`.
5. Pide las correcciones en el chat. No uses Reject: descarta el archivo.
6. Con Generate Tech Design, revisa `design.md`:
    - `Cubre: REQ-…` en cada parte y la lógica separada del modelo;
    - solo unittest, sin bibliotecas externas;
    - temporizadores que guarden el tiempo de inicio, no que sumen intervalos;
    - IDs escritos uno por uno, nunca rangos como «REQ-01 a REQ-16».
7. Si Kiro pregunta el lenguaje, elige Python.

## 4. Ejecuta las tareas y genera la evidencia

1. Revisa `tasks.md`. Las tareas con asterisco son opcionales para Kiro: pide que las de pruebas sean obligatorias. Con 4 tareas basta (código, pruebas, correr las pruebas y trazabilidad) y gastas menos créditos.
2. Pulsa Start task en cada tarea, una por una. Al terminar, revisa el archivo y elige Accept. Cuando pida permiso para un comando, elige Allow; evita Always allow mientras aprendes.
3. Al final, corre tú mismo:

```
python -m unittest -v
python trazabilidad.py --estricto; echo $LASTEXITCODE
```

4. Abre `matriz_trazabilidad.md` con Ctrl+Shift+V: cada REQ con su origen, el archivo y la línea donde se implementa, sus pruebas y si pasan. Con `--estricto` el script termina con código 1 si queda algún hueco.

Resultado de referencia, del 9 de noviembre de 2026: 16 requisitos de la lógica y 6 del sistema, 26 pruebas que pasan, 16 de 16 completos y 35.89 de 50 créditos del plan gratuito. El tutorial completo, con capturas, está en el sitio del material, en `kiro/`.

## Para la conferencia

No lo hagas en vivo: toma más tiempo del que tienes. Toma dos capturas, el `requirements.md` que generó Kiro desde la frase vaga y la matriz final, y úsalas en las láminas de Spec-Driven Development y de trazabilidad: «Esto generó Kiro a partir de la misma frase vaga, y esta matriz es la evidencia de que cada requisito tiene código y pruebas».

Si quieres ver a Kiro inventar números, como hizo el asistente en la demo, quita por un momento `product.md`. Sin la fuente normativa tendrá que suponer, y las reglas lo obligan a marcar cada número como SUPUESTO.
