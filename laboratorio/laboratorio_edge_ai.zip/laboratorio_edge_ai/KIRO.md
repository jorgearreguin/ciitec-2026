# Del requisito vago a la evidencia, con Kiro

Kiro hace la parte de la especificación: requisitos en EARS, diseño, tareas y código. Las reglas de `.kiro/steering/trazabilidad.md` obligan a que cada pieza lleve el mismo ID REQ-NN. `trazabilidad.py` cierra el hilo: ejecuta las pruebas y escribe la matriz que sirve como evidencia.

| Eslabón | Dónde vive | Cómo se marca |
| --- | --- | --- |
| Regla | `.kiro/steering/product.md` | ADDW: 6 s desde 20 km/h, 3.5 s desde 50 km/h |
| Requisito | `.kiro/specs/<nombre>/requirements.md` | `- **REQ-01** (Origen: ADDW) MIENTRAS …, EL DMS DEBE …` |
| Diseño | `design.md` | `Cubre: REQ-01, REQ-02` |
| Tarea | `tasks.md` | `_Requisitos: REQ-01_` |
| Código | `*.py` | comentario `# REQ-01` |
| Prueba | `test_*.py` | `test_req01_…` o `Verifica: REQ-01` en el docstring |
| Evidencia | `matriz_trazabilidad.md` | la genera `python trazabilidad.py` |

Es la misma cadena de la lámina de trazabilidad: regla → requisito de sistema → requisito de software → código → prueba → reporte.

## 1. Mira primero la matriz de la implementación de referencia

En esta carpeta:

```
python trazabilidad.py
```

Lee `referencia/requirements.md`, busca los `# REQ-NN` de `dms_logic.py`, corre las 23 pruebas y escribe `matriz_trazabilidad.md`. Vas a ver un hueco a propósito: la prueba `test_mismas_entradas_mismas_salidas` no tiene requisito. Es el tipo de hueco que la herramienta encuentra sola. Para cerrarlo, agrega un REQ-08 de determinismo o documenta por qué esa prueba no lo necesita.

Si quieres ver cómo se ve una falla, cambia en `dms_logic.py` el `>=` de la línea `t_ms - self._inicio_fuera >= umbral` por `>` y vuelve a correr el script: REQ-01 y REQ-02 aparecen con pruebas que no pasan.

## 2. Prepara el espacio de Kiro

1. Copia la carpeta `kiro_inicio` a otro lugar, por ejemplo `Documentos/dms_kiro`. Usa una carpeta aparte para que Kiro no reutilice el código de referencia.
2. Ábrela en Kiro. En Windows la carpeta `.kiro` se ve normal; si usas macOS, está oculta y se muestra con Cmd + Shift + punto.
3. En el panel de Steering deben aparecer `product`, `tech` y `trazabilidad`.

## 3. Crea la spec desde la frase vaga

1. En el panel de Specs crea una spec nueva de tipo Feature, con el flujo Requirements-First.
2. Pega solo la frase de `REQUISITO_DEL_CLIENTE.md`.
3. Usa Analyze Requirements para que Kiro marque ambigüedades y huecos antes del diseño.
4. Revisa `requirements.md` como en la demo de la plática:
    - **Los números:** REQ-01 y REQ-02 deben decir 3.5 s desde 50 km/h y 6 s desde 20 km/h, con origen ADDW.
    - **Los supuestos:** todo lo demás debe decir SUPUESTO y aparecer en «Preguntas para el cliente».
    - **Lo que falta:** cámara tapada, ojos cerrados y qué alerta gana si hay dos a la vez.
    - Compáralo con `referencia/requirements.md` de la carpeta del laboratorio.
5. Si Kiro numera 1.1, 1.2 en lugar de REQ-NN, pídele en el chat: «Usa los IDs REQ-NN de #trazabilidad».
6. Aprueba los requisitos y revisa que el diseño diga `Cubre: …` y cada tarea `_Requisitos: …_`.

## 4. Ejecuta las tareas y genera la evidencia

1. Ejecuta las tareas una por una y no todas de golpe, para que puedas revisar cada paso.
2. Después de cada tarea: `python trazabilidad.py`. El script encuentra solo la spec en `.kiro/specs`.
3. Al final, abre `matriz_trazabilidad.md`: cada REQ con su origen, el archivo y la línea donde se implementa, sus pruebas y si pasan.
4. Para un hook o para CI usa `python trazabilidad.py --estricto`: termina con código 1 si queda algún hueco.

## Para la conferencia

No lo hagas en vivo: toma más tiempo del que tienes. Toma dos capturas, el `requirements.md` que generó Kiro desde la frase vaga y la matriz final, y úsalas en las láminas de Spec-Driven Development y de trazabilidad: «Esto generó Kiro a partir de la misma frase vaga, y esta matriz es la evidencia de que cada requisito tiene código y pruebas».

Si quieres ver a Kiro inventar números, como hizo el asistente en la demo, quita por un momento `product.md`. Sin la fuente normativa tendrá que suponer, y las reglas lo obligan a marcar cada número como SUPUESTO.
