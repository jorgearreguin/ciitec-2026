"""Banco de pruebas de Edge AI: el mismo modelo en FP32, FP16 e INT8, en CPU y en GPU.

Que hace:
  1. Descarga MobileNetV2 (ONNX Model Zoo) y verifica su huella SHA-256.
  2. Crea una version FP16 (para la GPU) y una INT8 cuantizada con calibracion (para la CPU).
  3. Mide latencia p50 y p99, inferencias por segundo y tamano de cada version.
  4. Si le das fotos, mide cuantas veces la version optimizada coincide con la FP32.

Uso:
  python bench_quant.py
  python bench_quant.py --imagenes C:\\lab_edge_ai\\fotos     calibra y compara con tus fotos (jpg o png)
  python bench_quant.py --lote 16                            16 imagenes por inferencia

Material didactico: mide velocidad y tamano; la exactitud real se valida con datos reales.
"""

from __future__ import annotations

import argparse
import csv
import glob
import hashlib
import os
import platform
import subprocess
import sys
import time
import urllib.request

import numpy as np
import onnxruntime as ort

URLS_MODELO = [
    "https://github.com/onnx/models/raw/main/validated/vision/classification/mobilenet/model/mobilenetv2-12.onnx",
    "https://media.githubusercontent.com/media/onnx/models/main/validated/vision/classification/mobilenet/model/mobilenetv2-12.onnx",
]
SHA256_MODELO = "c0c3f76d93fa3fd6580652a45618618a220fced18babf65774ed169de0432ad5"
MEDIA = np.array([0.485, 0.456, 0.406], dtype=np.float32).reshape(1, 3, 1, 1)
DESVIACION = np.array([0.229, 0.224, 0.225], dtype=np.float32).reshape(1, 3, 1, 1)


# ---------------------------------------------------------------- modelo

def huella_sha256(ruta: str) -> str:
    digest = hashlib.sha256()
    with open(ruta, "rb") as archivo:
        for bloque in iter(lambda: archivo.read(1 << 20), b""):
            digest.update(bloque)
    return digest.hexdigest()


def obtener_modelo(ruta: str) -> str:
    if os.path.exists(ruta) and huella_sha256(ruta) == SHA256_MODELO:
        return ruta
    for url in URLS_MODELO:
        try:
            print(f"Descargando {url}")
            urllib.request.urlretrieve(url, ruta)
        except Exception as error:
            print(f"  fallo: {error}")
            continue
        if huella_sha256(ruta) == SHA256_MODELO:
            print("  modelo verificado con SHA-256")
            return ruta
        print("  el archivo no coincide con la huella esperada; pruebo la otra fuente")
    sys.exit("No pude descargar MobileNetV2. Descarga mobilenetv2-12.onnx desde "
             "github.com/onnx/models (carpeta validated/vision/classification/mobilenet/model) "
             "y pasalo con --modelo RUTA.")


def entrada_del_modelo(ruta: str):
    sesion = ort.InferenceSession(ruta, providers=["CPUExecutionProvider"])
    entrada = sesion.get_inputs()[0]
    return entrada.name, entrada.shape, entrada.type


def forma_concreta(forma, lote: int):
    concreta = []
    for i, dim in enumerate(forma):
        if isinstance(dim, int) and dim > 0:
            concreta.append(dim)
        else:
            concreta.append(lote if i == 0 else 224)
    if concreta:
        concreta[0] = lote
    return concreta


def datos_aleatorios(forma, tipo: str, cantidad: int, semilla: int = 0):
    generador = np.random.default_rng(semilla)
    datos = []
    for _ in range(cantidad):
        if "float" in tipo:
            datos.append(generador.standard_normal(forma).astype(np.float32))
        else:
            datos.append(generador.integers(0, 256, size=forma).astype(np.int32 if "int32" in tipo else np.int64))
    return datos


def cargar_fotos(carpeta: str, maximo: int, lado: int = 224):
    """Preprocesamiento ImageNet: lado corto a 256, recorte central de 224, normalizacion."""
    import cv2  # viene con mediapipe

    rutas = []
    for patron in ("*.jpg", "*.jpeg", "*.png", "*.JPG", "*.JPEG", "*.PNG"):
        rutas += glob.glob(os.path.join(carpeta, "**", patron), recursive=True)
    datos = []
    for ruta in sorted(set(rutas)):
        if len(datos) >= maximo:
            break
        imagen = cv2.imdecode(np.fromfile(ruta, dtype=np.uint8), cv2.IMREAD_COLOR)  # admite rutas con acentos
        if imagen is None:
            continue
        imagen = cv2.cvtColor(imagen, cv2.COLOR_BGR2RGB)
        alto, ancho = imagen.shape[:2]
        escala = 256.0 / min(alto, ancho)
        imagen = cv2.resize(imagen, (max(lado, round(ancho * escala)), max(lado, round(alto * escala))),
                            interpolation=cv2.INTER_AREA)
        alto, ancho = imagen.shape[:2]
        y0, x0 = (alto - lado) // 2, (ancho - lado) // 2
        imagen = imagen[y0:y0 + lado, x0:x0 + lado].astype(np.float32) / 255.0
        tensor = (imagen.transpose(2, 0, 1)[None, ...] - MEDIA) / DESVIACION
        datos.append(tensor.astype(np.float32))
    return datos


# ---------------------------------------------------------------- versiones optimizadas

def crear_fp16(ruta32: str, ruta16: str) -> None:
    import onnx
    from onnxruntime.transformers.float16 import convert_float_to_float16

    modelo16 = convert_float_to_float16(onnx.load(ruta32), keep_io_types=True)
    onnx.save(modelo16, ruta16)


def crear_int8(ruta32: str, ruta8: str, nombre_entrada: str, datos_calibracion, reducir_rango: bool) -> None:
    from onnxruntime.quantization import CalibrationDataReader, QuantFormat, QuantType, quantize_static
    from onnxruntime.quantization.shape_inference import quant_pre_process

    class LectorCalibracion(CalibrationDataReader):
        """Entrega los datos de calibracion uno por uno, como pide la cuantizacion estatica."""

        def __init__(self, nombre: str, datos):
            self.nombre = nombre
            self.datos = iter(datos)

        def get_next(self):
            x = next(self.datos, None)
            return None if x is None else {self.nombre: x}

    lector = LectorCalibracion(nombre_entrada, datos_calibracion)
    ruta_pre = os.path.splitext(ruta32)[0] + "-pre.onnx"
    # Para una red convolucional basta la inferencia de formas de ONNX; la simbolica pediria sympy.
    quant_pre_process(ruta32, ruta_pre, skip_symbolic_shape=True)
    quantize_static(ruta_pre, ruta8, lector,
                    quant_format=QuantFormat.QDQ, per_channel=False, reduce_range=reducir_rango,
                    activation_type=QuantType.QUInt8, weight_type=QuantType.QInt8)


# ---------------------------------------------------------------- medicion

def crear_sesion(ruta: str, proveedores):
    opciones = ort.SessionOptions()
    opciones.graph_optimization_level = ort.GraphOptimizationLevel.ORT_ENABLE_ALL
    opciones.log_severity_level = 3
    return ort.InferenceSession(ruta, sess_options=opciones, providers=proveedores)


def medir(sesion, nombre_entrada: str, x, corridas: int, calentamiento: int):
    for _ in range(calentamiento):
        sesion.run(None, {nombre_entrada: x})
    tiempos = []
    for _ in range(corridas):
        inicio = time.perf_counter()
        sesion.run(None, {nombre_entrada: x})
        tiempos.append((time.perf_counter() - inicio) * 1000.0)
    return tiempos


def clases(sesion, nombre_entrada: str, datos):
    return [int(np.argmax(sesion.run(None, {nombre_entrada: x})[0])) for x in datos]


def info_entorno() -> list[str]:
    lineas = [f"Sistema: {platform.platform()}",
              f"CPU: {platform.processor() or platform.machine()}",
              f"ONNX Runtime {ort.__version__}; proveedores: {', '.join(ort.get_available_providers())}"]
    try:
        gpu = subprocess.run(["nvidia-smi", "--query-gpu=name,driver_version,memory.total",
                              "--format=csv,noheader"], capture_output=True, text=True, timeout=10)
        if gpu.returncode == 0 and gpu.stdout.strip():
            lineas.append(f"GPU: {gpu.stdout.strip()}")
    except Exception:
        lineas.append("GPU: nvidia-smi no disponible")
    return lineas


def main(argv=None) -> list[dict]:
    parser = argparse.ArgumentParser(description="FP32, FP16 e INT8 en CPU y GPU con ONNX Runtime")
    parser.add_argument("--modelo", default="mobilenetv2-12.onnx")
    parser.add_argument("--imagenes", help="carpeta con fotos jpg o png para calibrar y comparar")
    parser.add_argument("--lote", type=int, default=1)
    parser.add_argument("--corridas", type=int, default=200)
    parser.add_argument("--calentamiento", type=int, default=20)
    parser.add_argument("--reducir-rango", dest="reducir_rango", action="store_true",
                        help="cuantiza pesos a 7 bits (CPU sin VNNI)")
    parser.add_argument("--sin-descarga", dest="sin_descarga", action="store_true",
                        help="usa --modelo tal cual, sin descargar ni verificar")
    args = parser.parse_args(argv)

    if hasattr(ort, "preload_dlls"):  # carga CUDA y cuDNN instalados con pip (Windows)
        try:
            ort.preload_dlls()
        except Exception as error:
            print(f"Aviso: no se precargaron las DLL de CUDA ({error})")

    for linea in info_entorno():
        print(linea)

    ruta32 = args.modelo if args.sin_descarga else obtener_modelo(args.modelo)
    nombre, forma, tipo = entrada_del_modelo(ruta32)
    forma1 = forma_concreta(forma, 1)
    formaN = forma_concreta(forma, args.lote)

    fotos = cargar_fotos(args.imagenes, 200) if args.imagenes else []
    if fotos:
        mitad = max(1, len(fotos) // 2)
        calibracion, prueba = fotos[:mitad], fotos[mitad:] or fotos
        print(f"Fotos: {len(fotos)} ({len(calibracion)} para calibrar, {len(prueba)} para comparar)")
    else:
        calibracion, prueba = datos_aleatorios(forma1, tipo, 32, semilla=1), []
        print("Sin fotos: calibro con datos aleatorios y no mido coincidencia (usa --imagenes).")

    base, _ = os.path.splitext(ruta32)
    ruta16, ruta8 = base + "-fp16.onnx", base + "-int8.onnx"
    variantes = {"FP32": ruta32}
    try:
        crear_fp16(ruta32, ruta16)
        variantes["FP16"] = ruta16
    except Exception as error:
        print(f"No pude crear la version FP16: {error}")
    try:
        crear_int8(ruta32, ruta8, nombre, calibracion, args.reducir_rango)
        variantes["INT8"] = ruta8
    except Exception as error:
        print(f"No pude crear la version INT8: {error}")

    disponibles = ort.get_available_providers()
    gpu = ["CUDAExecutionProvider", "CPUExecutionProvider"]
    # (precision que se reporta, donde corre, version del modelo que se carga, proveedores)
    casos = [("FP32", "CPU", "FP32", ["CPUExecutionProvider"]),
             ("INT8", "CPU", "INT8", ["CPUExecutionProvider"])]
    if "CUDAExecutionProvider" in disponibles:
        casos += [("FP32", "GPU (CUDA)", "FP32", gpu), ("FP16", "GPU (CUDA)", "FP16", gpu)]
    else:
        print("La GPU no esta disponible para ONNX Runtime; solo mido la CPU (revisa la guia, paso 1).")
    if "TensorrtExecutionProvider" in disponibles:  # opcional: requiere TensorRT instalado
        casos += [("FP16", "GPU (TensorRT)", "FP32",
                   [("TensorrtExecutionProvider", {"trt_fp16_enable": True})] + gpu)]

    x = datos_aleatorios(formaN, tipo, 1, semilla=7)[0]
    referencia = None
    filas = []
    for precision, donde, version, proveedores in casos:
        ruta = variantes.get(version)
        if ruta is None:
            continue
        try:
            sesion = crear_sesion(ruta, proveedores)
        except Exception as error:
            print(f"Omito {precision} en {donde}: {error}")
            continue
        activo = sesion.get_providers()[0]
        if "GPU" in donde and activo == "CPUExecutionProvider":
            print(f"Omito {precision} en {donde}: la sesion cayo a la CPU")
            continue
        tiempos = medir(sesion, nombre, x, args.corridas, args.calentamiento)
        p50, p99 = float(np.percentile(tiempos, 50)), float(np.percentile(tiempos, 99))
        coincidencia = ""
        if prueba:
            clases_variante = clases(sesion, nombre, prueba)
            if referencia is None:  # la primera fila es FP32 en CPU
                referencia = clases_variante
            iguales = sum(a == b for a, b in zip(referencia, clases_variante))
            coincidencia = f"{100.0 * iguales / len(referencia):.1f} %"
        filas.append({"precision": precision, "donde": donde, "tamano_mb": os.path.getsize(ruta) / 1e6,
                      "p50_ms": p50, "p99_ms": p99, "inferencias_s": 1000.0 * args.lote / p50,
                      "coincidencia": coincidencia})

    if not filas:
        sys.exit("No se pudo medir ninguna version.")
    p50_cpu32 = filas[0]["p50_ms"]
    encabezado = ("| Precision | Donde corre | Tamano (MB) | p50 (ms) | p99 (ms) | Inferencias/s "
                  "| Contra CPU FP32 | Coincide con FP32 |")
    lineas = [f"Modelo: {os.path.basename(ruta32)}   lote: {args.lote}   corridas: {args.corridas}", "",
              encabezado, "|---|---|---|---|---|---|---|---|"]
    for f in filas:
        lineas.append(f"| {f['precision']} | {f['donde']} | {f['tamano_mb']:.1f} | {f['p50_ms']:.2f} | "
                      f"{f['p99_ms']:.2f} | {f['inferencias_s']:.0f} | {p50_cpu32 / f['p50_ms']:.1f}x | "
                      f"{f['coincidencia'] or 'sin fotos'} |")
    lineas += ["", "Referencia publicada por la ONNX Model Zoo para MobileNetV2: FP32 13.3 MB y 69.48 % top-1;",
               "INT8 3.5 MB y 68.30 % top-1 (en ImageNet)."]
    tabla = "\n".join(lineas)
    print()
    print(tabla)
    with open("resultados_bench.md", "w", encoding="utf-8") as archivo:
        archivo.write("\n".join(info_entorno()) + "\n\n" + tabla + "\n")
    with open("resultados_bench.csv", "w", newline="", encoding="utf-8") as archivo:
        escritor = csv.DictWriter(archivo, fieldnames=list(filas[0].keys()))
        escritor.writeheader()
        escritor.writerows(filas)
    print("\nGuardado en resultados_bench.md y resultados_bench.csv")
    return filas


if __name__ == "__main__":
    main()
