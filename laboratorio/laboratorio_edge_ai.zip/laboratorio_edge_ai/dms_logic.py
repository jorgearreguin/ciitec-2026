"""Logica de decision del DMS de laboratorio: determinista y sin dependencias.

La red neuronal solo estima (ojos cerrados, mirada fuera del camino). Esta logica
decide la alerta. Cada regla sale de un requisito escrito con EARS. Los tiempos se
manejan en milisegundos enteros, como en un sistema embebido, para que las
comparaciones en los valores limite sean exactas.

Requisitos (EARS):
REQ-01  Mientras la velocidad sea de 50 km/h o mas, cuando la mirada este fuera del
        camino durante 3.5 s o mas, el DMS emitira una alerta de distraccion.
REQ-02  Mientras la velocidad sea de 20 km/h o mas y menor de 50 km/h, cuando la mirada
        este fuera del camino durante 6 s o mas, el DMS emitira una alerta de distraccion.
REQ-03  Mientras la velocidad sea menor de 20 km/h, el DMS no emitira alertas de
        distraccion ni de somnolencia.
REQ-04  Mientras la velocidad sea de 20 km/h o mas, cuando los ojos esten cerrados
        durante 2 s o mas, el DMS emitira una alerta de somnolencia.
REQ-05  Si el rostro no es visible durante 2 s o mas, entonces el DMS indicara que no
        esta disponible.
REQ-06  Cuando la mirada regrese al camino, el DMS reiniciara el conteo de distraccion.
REQ-07  Si se cumplen a la vez las condiciones de somnolencia y de distraccion, el DMS
        emitira la alerta de somnolencia.

Los tiempos de REQ-01 y REQ-02 siguen los del reglamento europeo ADDW citados en la
guia. Los de REQ-04 y REQ-05 son valores de demostracion, no de una norma.
Material didactico: no esta validado para uso en un vehiculo.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Optional


class Alerta(Enum):
    NINGUNA = "NINGUNA"
    DISTRACCION = "DISTRACCION"
    SOMNOLENCIA = "SOMNOLENCIA"
    NO_DISPONIBLE = "DMS NO DISPONIBLE"


@dataclass(frozen=True)
class Umbrales:
    v_minima_kmh: float = 20.0       # REQ-02 y REQ-03
    v_alta_kmh: float = 50.0         # REQ-01 y REQ-02
    distraccion_baja_ms: int = 6000  # REQ-02
    distraccion_alta_ms: int = 3500  # REQ-01
    ojos_cerrados_ms: int = 2000     # REQ-04 (demostracion)
    sin_rostro_ms: int = 2000        # REQ-05 (demostracion)


UMBRALES_POR_OMISION = Umbrales()


def umbral_distraccion_ms(velocidad_kmh: float, u: Umbrales = UMBRALES_POR_OMISION) -> Optional[int]:
    """Tiempo maximo de mirada fuera del camino para una velocidad (REQ-01 a REQ-03).

    Devuelve None cuando, por la velocidad, el DMS no emite alertas.
    """
    if velocidad_kmh < u.v_minima_kmh:
        return None
    if velocidad_kmh < u.v_alta_kmh:
        return u.distraccion_baja_ms
    return u.distraccion_alta_ms


class LogicaDMS:
    """Maquina de decision del DMS. Se llama una vez por cuadro con el tiempo del cuadro."""

    def __init__(self, umbrales: Umbrales = UMBRALES_POR_OMISION):
        self.u = umbrales
        self._inicio_fuera: Optional[int] = None
        self._inicio_cerrados: Optional[int] = None
        self._inicio_sin_rostro: Optional[int] = None

    def reiniciar(self) -> None:
        self._inicio_fuera = None
        self._inicio_cerrados = None
        self._inicio_sin_rostro = None

    @staticmethod
    def _duracion(inicio: Optional[int], t_ms: int) -> int:
        return 0 if inicio is None else t_ms - inicio

    def tiempos(self, t_ms: int) -> dict:
        """Cuanto tiempo lleva activa cada condicion, para mostrarlo en pantalla."""
        return {
            "fuera_ms": self._duracion(self._inicio_fuera, t_ms),
            "cerrados_ms": self._duracion(self._inicio_cerrados, t_ms),
            "sin_rostro_ms": self._duracion(self._inicio_sin_rostro, t_ms),
        }

    def actualizar(self, t_ms: int, velocidad_kmh: float, rostro_visible: bool,
                   mirada_fuera: bool, ojos_cerrados: bool) -> Alerta:
        # REQ-05: sin rostro no hay mirada ni ojos que evaluar.
        if not rostro_visible:
            if self._inicio_sin_rostro is None:
                self._inicio_sin_rostro = t_ms
            self._inicio_fuera = None
            self._inicio_cerrados = None
            if t_ms - self._inicio_sin_rostro >= self.u.sin_rostro_ms:
                return Alerta.NO_DISPONIBLE
            return Alerta.NINGUNA
        self._inicio_sin_rostro = None

        # Cada conteo arranca con su condicion y se reinicia cuando desaparece (REQ-06).
        if ojos_cerrados:
            if self._inicio_cerrados is None:
                self._inicio_cerrados = t_ms
        else:
            self._inicio_cerrados = None

        if mirada_fuera:
            if self._inicio_fuera is None:
                self._inicio_fuera = t_ms
        else:
            self._inicio_fuera = None

        # REQ-03: debajo de la velocidad minima no hay alertas.
        umbral = umbral_distraccion_ms(velocidad_kmh, self.u)
        if umbral is None:
            return Alerta.NINGUNA

        # REQ-04 y REQ-07: la somnolencia tiene prioridad.
        if self._inicio_cerrados is not None and t_ms - self._inicio_cerrados >= self.u.ojos_cerrados_ms:
            return Alerta.SOMNOLENCIA

        # REQ-01 y REQ-02.
        if self._inicio_fuera is not None and t_ms - self._inicio_fuera >= umbral:
            return Alerta.DISTRACCION

        return Alerta.NINGUNA
