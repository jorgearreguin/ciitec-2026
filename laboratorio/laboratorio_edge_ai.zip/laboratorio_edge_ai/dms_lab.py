"""DMS de laboratorio: distraccion y somnolencia con la camara web y MediaPipe.

Camino del dato (el mismo del diagrama de la guia):
  camara -> preprocesamiento -> red neuronal (Face Landmarker de MediaPipe)
  -> rasgos (apertura de ojos EAR y pose de la cabeza) -> filtro temporal
  -> logica determinista (dms_logic.py) -> alerta

Uso:
  python dms_lab.py                         camara 0, velocidad simulada de 80 km/h
  python dms_lab.py --camara 1              otra camara
  python dms_lab.py --grabar prueba         guarda prueba_crudo.mp4, prueba_demo.mp4 y prueba_tiempos.csv
  python dms_lab.py --video prueba_crudo.mp4 --sin-ventana
                                            repite la prueba con el video grabado (prueba tipo SIL)

Teclas en la ventana: 0, 1, 2 y 3 = 0, 10, 30 y 80 km/h; c = recalibrar; q o Esc = salir.

Material didactico: no esta validado para uso en un vehiculo.
"""

from __future__ import annotations

import argparse
import csv
import math
import os
import sys
import time
import urllib.request
from collections import deque
from dataclasses import dataclass

import cv2
import numpy as np
import mediapipe as mp
from mediapipe.tasks.python import vision
from mediapipe.tasks.python.core.base_options import BaseOptions

from dms_logic import Alerta, LogicaDMS, umbral_distraccion_ms

MODELO_URL = ("https://storage.googleapis.com/mediapipe-models/face_landmarker/"
              "face_landmarker/float16/latest/face_landmarker.task")

# Puntos de la malla facial de MediaPipe para la apertura del ojo (EAR):
# esquina externa, dos puntos superiores, esquina interna, dos puntos inferiores.
OJO_DERECHO = (33, 160, 158, 133, 153, 144)
OJO_IZQUIERDO = (362, 385, 387, 263, 373, 380)

TECLAS_VELOCIDAD = {ord("0"): 0, ord("1"): 10, ord("2"): 30, ord("3"): 80}
VENTANA_PERCLOS_MS = 60_000


@dataclass(frozen=True)
class Punto:
    x: float
    y: float


@dataclass
class Rasgos:
    ear: float
    giro: float      # yaw, grados
    cabeceo: float   # pitch, grados
    puntos: list


# ---------------------------------------------------------------- modelo y detector

def descargar_modelo(ruta: str) -> None:
    if os.path.exists(ruta) and os.path.getsize(ruta) > 1_000_000:
        return
    print(f"Descargando el modelo Face Landmarker en {ruta} ...")
    try:
        urllib.request.urlretrieve(MODELO_URL, ruta)
    except Exception as error:  # sin internet, proxy, etc.
        sys.exit(f"No pude descargar el modelo ({error}).\n"
                 f"Descargalo a mano desde:\n  {MODELO_URL}\ny guardalo como {ruta}")


def crear_detector(ruta_modelo: str):
    # Se pasa el modelo como bytes para evitar problemas con rutas que tengan acentos en Windows.
    with open(ruta_modelo, "rb") as archivo:
        modelo = archivo.read()
    opciones = vision.FaceLandmarkerOptions(
        base_options=BaseOptions(model_asset_buffer=modelo),
        running_mode=vision.RunningMode.VIDEO,
        num_faces=1,
        output_face_blendshapes=False,
        output_facial_transformation_matrixes=True,
    )
    return vision.FaceLandmarker.create_from_options(opciones)


# ---------------------------------------------------------------- rasgos

def ear(puntos, indices, ancho: int, alto: int) -> float:
    """Eye Aspect Ratio: alto del ojo entre ancho del ojo. Baja mucho cuando el ojo se cierra."""
    p = [np.array([puntos[i].x * ancho, puntos[i].y * alto]) for i in indices]
    vertical = np.linalg.norm(p[1] - p[5]) + np.linalg.norm(p[2] - p[4])
    horizontal = 2.0 * np.linalg.norm(p[0] - p[3])
    return float(vertical / horizontal) if horizontal > 0 else 0.0


def angulos_cabeza(matriz) -> tuple[float, float]:
    """Giro (yaw) y cabeceo (pitch) en grados a partir de la matriz de transformacion facial."""
    r = np.asarray(matriz, dtype=float)[:3, :3]
    escala = np.linalg.norm(r, axis=0)
    r = r / np.where(escala == 0, 1.0, escala)
    cabeceo = math.degrees(math.atan2(r[2, 1], r[2, 2]))
    giro = math.degrees(math.atan2(-r[2, 0], math.hypot(r[2, 1], r[2, 2])))
    return giro, cabeceo


def diferencia_angular(a: float, b: float) -> float:
    """Diferencia a - b en grados, llevada al intervalo [-180, 180)."""
    return (a - b + 180.0) % 360.0 - 180.0


def extraer_rasgos(resultado, ancho: int, alto: int):
    if not resultado.face_landmarks:
        return None
    puntos = resultado.face_landmarks[0]
    valor_ear = (ear(puntos, OJO_DERECHO, ancho, alto) + ear(puntos, OJO_IZQUIERDO, ancho, alto)) / 2.0
    giro = cabeceo = 0.0
    if resultado.facial_transformation_matrixes:
        giro, cabeceo = angulos_cabeza(resultado.facial_transformation_matrixes[0])
    return Rasgos(valor_ear, giro, cabeceo, puntos)


# ---------------------------------------------------------------- utilidades

def percentil(valores, p: float) -> float:
    return float(np.percentile(np.asarray(valores, dtype=float), p)) if valores else float("nan")


def sonar_alerta() -> None:
    if os.name == "nt":
        try:
            import winsound
            winsound.MessageBeep(winsound.MB_ICONHAND)
        except Exception:
            pass


def abrir_fuente(args):
    if args.video:
        captura = cv2.VideoCapture(args.video)
    else:
        captura = None
        if os.name == "nt":
            captura = cv2.VideoCapture(args.camara, cv2.CAP_DSHOW)
            if not captura.isOpened():
                captura = None
        if captura is None:
            captura = cv2.VideoCapture(args.camara)
        captura.set(cv2.CAP_PROP_FRAME_WIDTH, args.ancho)
        captura.set(cv2.CAP_PROP_FRAME_HEIGHT, args.alto)
    if not captura.isOpened():
        sys.exit("No pude abrir la camara o el video. Prueba con --camara 1 o revisa la ruta del video.")
    fps = captura.get(cv2.CAP_PROP_FPS)
    return captura, (fps if fps and fps > 1 else 30.0)


def fps_grabacion(args, fps_fuente: float, intervalos) -> float:
    """Con camara, los FPS medidos; con video, los del archivo. Asi el video grabado dura lo real."""
    if args.video or not intervalos:
        return fps_fuente
    return max(1.0, min(60.0, 1000.0 / (sum(intervalos) / len(intervalos))))


def abrir_grabadores(args, fps: float, ancho: int, alto: int):
    fourcc = cv2.VideoWriter_fourcc(*"mp4v")
    crudo = cv2.VideoWriter(f"{args.grabar}_crudo.mp4", fourcc, fps, (ancho, alto))
    demo = cv2.VideoWriter(f"{args.grabar}_demo.mp4", fourcc, fps, (ancho, alto))
    return crudo, demo


def ruta_tiempos(base_video: str) -> str:
    if base_video.endswith("_crudo.mp4"):
        return base_video[: -len("_crudo.mp4")] + "_tiempos.csv"
    return os.path.splitext(base_video)[0] + "_tiempos.csv"


def cargar_tiempos(ruta_video: str):
    """Tiempos y velocidades grabados junto al video, para repetir la prueba igual."""
    ruta = ruta_tiempos(ruta_video)
    if not os.path.exists(ruta):
        return None
    with open(ruta, newline="", encoding="utf-8") as archivo:
        return [(int(fila["t_ms"]), float(fila["velocidad_kmh"])) for fila in csv.DictReader(archivo)]


# ---------------------------------------------------------------- dibujo

def texto(img, linea: str, x: int, y: int, escala=0.55, color=(255, 255, 255), grosor=1):
    cv2.putText(img, linea, (x, y), cv2.FONT_HERSHEY_SIMPLEX, escala, (0, 0, 0), grosor + 2, cv2.LINE_AA)
    cv2.putText(img, linea, (x, y), cv2.FONT_HERSHEY_SIMPLEX, escala, color, grosor, cv2.LINE_AA)


def pintar(img, estado: dict) -> None:
    alto, ancho = img.shape[:2]
    if estado.get("puntos") is not None:
        color = (0, 0, 255) if estado.get("cerrados") else (0, 220, 0)
        for i in OJO_DERECHO + OJO_IZQUIERDO:
            p = estado["puntos"][i]
            cv2.circle(img, (int(p.x * ancho), int(p.y * alto)), 2, color, -1)

    capa = img.copy()
    cv2.rectangle(capa, (0, 0), (ancho, 150), (0, 0, 0), -1)
    cv2.addWeighted(capa, 0.45, img, 0.55, 0, img)

    umbral = umbral_distraccion_ms(estado["velocidad"])
    linea_umbral = (f"Umbral de distraccion: {umbral / 1000:.1f} s" if umbral is not None
                    else "Sin alertas: velocidad menor de 20 km/h")
    texto(img, f"Velocidad simulada: {estado['velocidad']:.0f} km/h   (teclas 0, 1, 2, 3)", 10, 22)
    texto(img, linea_umbral, 10, 44)
    texto(img, f"Mirada fuera: {estado['fuera_ms'] / 1000:.1f} s    Ojos cerrados: {estado['cerrados_ms'] / 1000:.1f} s", 10, 66)
    if estado.get("ear") is not None and estado.get("ear_base"):
        texto(img, f"EAR {estado['ear']:.2f} (base {estado['ear_base']:.2f})   giro {estado['dgiro']:+.0f} grados"
                   f"   cabeceo {estado['dcabeceo']:+.0f} grados", 10, 88)
    texto(img, f"PERCLOS 60 s: {estado['perclos'] * 100:.0f} %", 10, 110)
    texto(img, f"Inferencia {estado['inferencia_ms']:.1f} ms   Procesamiento {estado['procesamiento_ms']:.1f} ms"
               f"   {estado['fps']:.0f} FPS", 10, 132)

    if estado["calibrando"]:
        cv2.rectangle(img, (0, alto - 60), (ancho, alto), (0, 180, 255), -1)
        texto(img, "CALIBRANDO: mira al frente con los ojos abiertos", 12, alto - 22, 0.7, (0, 0, 0), 2)
    elif estado["alerta"] != Alerta.NINGUNA:
        fondo = (90, 90, 90) if estado["alerta"] == Alerta.NO_DISPONIBLE else (0, 0, 220)
        cv2.rectangle(img, (0, alto - 70), (ancho, alto), fondo, -1)
        texto(img, estado["alerta"].value, 12, alto - 22, 1.1, (255, 255, 255), 3)


# ---------------------------------------------------------------- ciclo principal

def ejecutar(args, fabrica_detector=None) -> dict:
    if fabrica_detector is None:
        descargar_modelo(args.modelo)
        detector = crear_detector(args.modelo)
    else:
        detector = fabrica_detector()

    captura, fps_fuente = abrir_fuente(args)
    tiempos_grabados = cargar_tiempos(args.video) if args.video else None
    if tiempos_grabados:
        print(f"Usando {len(tiempos_grabados)} tiempos y velocidades grabados para repetir la prueba.")

    logica = LogicaDMS()
    velocidad = float(args.velocidad if args.velocidad is not None else 80)
    calibracion, base = [], None
    calibrando, inicio_calibracion = True, None
    perclos = deque()
    intervalos = deque(maxlen=30)
    latencias = {"preprocesamiento": [], "inferencia": [], "logica": [], "procesamiento": []}
    registro, eventos, tiempos_salida, pendientes = [], [], [], []
    alerta_previa = Alerta.NINGUNA
    escritor_crudo = escritor_demo = None
    t_inicio = time.perf_counter()
    ts_previo, indice = -1, 0

    while True:
        ok, cuadro = captura.read()
        t_lectura = time.perf_counter()
        if not ok:
            break
        alto, ancho = cuadro.shape[:2]

        # Tiempo del cuadro: grabado, del video o del reloj.
        if tiempos_grabados and indice < len(tiempos_grabados):
            ts_ms, velocidad_grabada = tiempos_grabados[indice]
            if args.velocidad is None:
                velocidad = velocidad_grabada
        elif args.video:
            ts_ms = int(round(indice * 1000.0 / fps_fuente))
        else:
            ts_ms = int((t_lectura - t_inicio) * 1000)
        if ts_ms <= ts_previo:  # MediaPipe exige tiempos crecientes
            ts_ms = ts_previo + 1
        if ts_previo >= 0:
            intervalos.append(ts_ms - ts_previo)
        ts_previo = ts_ms
        indice += 1

        # Preprocesamiento e inferencia.
        t0 = time.perf_counter()
        rgb = cv2.cvtColor(cuadro, cv2.COLOR_BGR2RGB)
        imagen = mp.Image(image_format=mp.ImageFormat.SRGB, data=rgb)
        t1 = time.perf_counter()
        resultado = detector.detect_for_video(imagen, ts_ms)
        t2 = time.perf_counter()

        # Rasgos, filtro temporal y logica.
        rasgos = extraer_rasgos(resultado, ancho, alto)
        cerrados = fuera = False
        dgiro = dcabeceo = 0.0
        alerta = Alerta.NINGUNA
        if calibrando:
            if inicio_calibracion is None:
                inicio_calibracion = ts_ms
            if rasgos is not None:
                calibracion.append((rasgos.ear, rasgos.giro, rasgos.cabeceo))
            if ts_ms - inicio_calibracion >= args.calibracion * 1000 and len(calibracion) >= 10:
                datos = np.array(calibracion)
                base = {"ear": float(np.median(datos[:, 0])), "giro": float(np.median(datos[:, 1])),
                        "cabeceo": float(np.median(datos[:, 2]))}
                calibrando = False
                logica.reiniciar()
                print(f"Calibracion lista: EAR base {base['ear']:.3f}")
        else:
            if rasgos is not None:
                cerrados = rasgos.ear < args.umbral_ojos * base["ear"]
                dgiro = diferencia_angular(rasgos.giro, base["giro"])
                dcabeceo = diferencia_angular(rasgos.cabeceo, base["cabeceo"])
                fuera = abs(dgiro) > args.giro or abs(dcabeceo) > args.cabeceo
            alerta = logica.actualizar(ts_ms, velocidad, rasgos is not None, fuera, cerrados)
            perclos.append((ts_ms, bool(cerrados)))
            while perclos and ts_ms - perclos[0][0] > VENTANA_PERCLOS_MS:
                perclos.popleft()
        t3 = time.perf_counter()

        preprocesamiento_ms = (t1 - t0) * 1000
        inferencia_ms = (t2 - t1) * 1000
        logica_ms = (t3 - t2) * 1000
        procesamiento_ms = (t3 - t0) * 1000
        latencias["preprocesamiento"].append(preprocesamiento_ms)
        latencias["inferencia"].append(inferencia_ms)
        latencias["logica"].append(logica_ms)
        latencias["procesamiento"].append(procesamiento_ms)

        if alerta != alerta_previa:
            eventos.append((ts_ms, alerta.value))
            print(f"{ts_ms / 1000:8.2f} s  {alerta.value}")
            if alerta != Alerta.NINGUNA:
                sonar_alerta()
            alerta_previa = alerta

        tiempos = logica.tiempos(ts_ms)
        valor_perclos = (sum(1 for _, c in perclos if c) / len(perclos)) if perclos else 0.0
        registro.append({
            "t_ms": ts_ms, "velocidad_kmh": velocidad, "rostro": int(rasgos is not None),
            "ear": round(rasgos.ear, 4) if rasgos else "", "giro": round(dgiro, 1), "cabeceo": round(dcabeceo, 1),
            "ojos_cerrados": int(cerrados), "mirada_fuera": int(fuera), "alerta": alerta.value,
            "preprocesamiento_ms": round(preprocesamiento_ms, 3), "inferencia_ms": round(inferencia_ms, 3),
            "logica_ms": round(logica_ms, 3),
        })

        if args.sin_ventana and not args.grabar:
            continue  # repeticion sin ventana: no hace falta dibujar

        espejo = args.espejo and not args.video
        vista = cv2.flip(cuadro, 1) if espejo else cuadro.copy()
        puntos_vista = None
        if rasgos is not None:
            puntos_vista = {i: Punto(1.0 - rasgos.puntos[i].x if espejo else rasgos.puntos[i].x,
                                     rasgos.puntos[i].y)
                            for i in OJO_DERECHO + OJO_IZQUIERDO}
        fps = 1000.0 / (sum(intervalos) / len(intervalos)) if intervalos else 0.0
        pintar(vista, {
            "velocidad": velocidad, "fuera_ms": tiempos["fuera_ms"], "cerrados_ms": tiempos["cerrados_ms"],
            "ear": rasgos.ear if rasgos else None, "ear_base": base["ear"] if base else None,
            "dgiro": dgiro, "dcabeceo": dcabeceo, "perclos": valor_perclos,
            "inferencia_ms": inferencia_ms, "procesamiento_ms": procesamiento_ms, "fps": fps,
            "calibrando": calibrando, "alerta": alerta, "cerrados": cerrados, "puntos": puntos_vista,
        })
        # Grabacion: video crudo (para repetir la prueba), tiempos y video con capas (para la conferencia).
        # Los primeros cuadros esperan en memoria hasta medir los FPS reales de la camara.
        if args.grabar:
            tiempos_salida.append((ts_ms, velocidad))
            if escritor_crudo is None:
                pendientes.append((cuadro, vista))
                if len(pendientes) >= 15:
                    escritor_crudo, escritor_demo = abrir_grabadores(args, fps_grabacion(args, fps_fuente, intervalos),
                                                                     ancho, alto)
                    for crudo, capa in pendientes:
                        escritor_crudo.write(crudo)
                        escritor_demo.write(capa)
                    pendientes = []
            else:
                escritor_crudo.write(cuadro)
                escritor_demo.write(vista)

        if not args.sin_ventana:
            cv2.imshow("DMS de laboratorio (q para salir)", vista)
            tecla = cv2.waitKey(1) & 0xFF
            if tecla in (ord("q"), 27):
                break
            if tecla in TECLAS_VELOCIDAD:
                velocidad = float(TECLAS_VELOCIDAD[tecla])
            if tecla == ord("c"):
                calibracion, base, calibrando, inicio_calibracion = [], None, True, None

    captura.release()
    if pendientes:  # grabacion muy corta: se escribe lo que haya
        alto, ancho = pendientes[0][0].shape[:2]
        escritor_crudo, escritor_demo = abrir_grabadores(args, fps_grabacion(args, fps_fuente, intervalos),
                                                         ancho, alto)
        for crudo, capa in pendientes:
            escritor_crudo.write(crudo)
            escritor_demo.write(capa)
    if escritor_crudo is not None:
        escritor_crudo.release()
        escritor_demo.release()
        with open(f"{args.grabar}_tiempos.csv", "w", newline="", encoding="utf-8") as archivo:
            escritor = csv.writer(archivo)
            escritor.writerow(["t_ms", "velocidad_kmh"])
            escritor.writerows(tiempos_salida)
    if not args.sin_ventana:
        cv2.destroyAllWindows()
    if hasattr(detector, "close"):
        detector.close()

    if registro:
        with open(args.registro, "w", newline="", encoding="utf-8") as archivo:
            escritor = csv.DictWriter(archivo, fieldnames=list(registro[0].keys()))
            escritor.writeheader()
            escritor.writerows(registro)

    duracion_s = (registro[-1]["t_ms"] - registro[0]["t_ms"]) / 1000 if len(registro) > 1 else 0.0
    resumen = {
        "cuadros": len(registro),
        "duracion_s": duracion_s,
        "fps_promedio": (len(registro) - 1) / duracion_s if duracion_s > 0 else 0.0,
        "latencias": {etapa: {"p50": percentil(v, 50), "p95": percentil(v, 95), "p99": percentil(v, 99)}
                      for etapa, v in latencias.items()},
        "eventos": eventos,
    }
    imprimir_resumen(resumen, args)
    return resumen


def imprimir_resumen(resumen: dict, args) -> None:
    print()
    print(f"Cuadros: {resumen['cuadros']}   Duracion: {resumen['duracion_s']:.1f} s   "
          f"FPS promedio: {resumen['fps_promedio']:.1f}")
    print("Latencia por etapa (ms):     p50      p95      p99")
    for etapa, valores in resumen["latencias"].items():
        print(f"  {etapa:<20} {valores['p50']:8.2f} {valores['p95']:8.2f} {valores['p99']:8.2f}")
    print("Cambios de alerta:")
    for t_ms, alerta in resumen["eventos"]:
        print(f"  {t_ms / 1000:8.2f} s  {alerta}")
    print(f"Registro por cuadro guardado en {args.registro}")


def leer_argumentos(argv=None):
    parser = argparse.ArgumentParser(description="DMS de laboratorio con MediaPipe")
    parser.add_argument("--camara", type=int, default=0, help="indice de la camara (0 por omision)")
    parser.add_argument("--video", help="video grabado en lugar de la camara")
    parser.add_argument("--ancho", type=int, default=1280)
    parser.add_argument("--alto", type=int, default=720)
    parser.add_argument("--velocidad", type=float, default=None,
                        help="velocidad simulada en km/h (80 por omision, o la grabada con el video)")
    parser.add_argument("--modelo", default="face_landmarker.task")
    parser.add_argument("--calibracion", type=float, default=2.0, help="segundos de calibracion al inicio")
    parser.add_argument("--umbral-ojos", dest="umbral_ojos", type=float, default=0.7,
                        help="ojos cerrados si el EAR baja de esta fraccion del EAR base")
    parser.add_argument("--giro", type=float, default=25.0, help="grados de giro para mirada fuera")
    parser.add_argument("--cabeceo", type=float, default=20.0, help="grados de cabeceo para mirada fuera")
    parser.add_argument("--grabar", help="nombre base para grabar video crudo, video con capas y tiempos")
    parser.add_argument("--registro", default="dms_registro.csv")
    parser.add_argument("--sin-ventana", dest="sin_ventana", action="store_true",
                        help="no abre ventana; util para repetir pruebas con un video")
    parser.add_argument("--sin-espejo", dest="espejo", action="store_false",
                        help="muestra la imagen sin efecto espejo")
    return parser.parse_args(argv)


if __name__ == "__main__":
    ejecutar(leer_argumentos())
