---
inclusion: always
---

# Tecnología

- Python 3.10 o más reciente.
- Estructura plana: el módulo de la lógica y los archivos `test_*.py` van en la raíz del proyecto, sin carpetas `src/` ni `tests/`, para que `python -m unittest` y `trazabilidad.py` los encuentren.
- La lógica de decisión va en un módulo propio, sin dependencias externas y con tiempos en milisegundos enteros, para que las comparaciones en los límites sean exactas.
- Pruebas con unittest (no pytest): `python -m unittest -v`.
- La lógica no importa MediaPipe ni ninguna biblioteca de visión; la cámara y el modelo viven en otro módulo.
- Evidencia: `python trazabilidad.py` genera `matriz_trazabilidad.md` y `matriz_trazabilidad.csv`.
