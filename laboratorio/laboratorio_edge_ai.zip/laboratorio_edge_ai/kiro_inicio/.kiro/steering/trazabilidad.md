---
inclusion: always
---

# Reglas de trazabilidad (obligatorias)

Todo lo que se especifique o programe en este proyecto debe poder seguirse como un hilo:
regla → requisito → diseño → tarea → código → prueba → evidencia.

## Requisitos (requirements.md)

- Escribe en español.
- Cada criterio de aceptación lleva un identificador único REQ-NN (REQ-01, REQ-02…) al inicio de la línea, en negritas. No uses la numeración 1.1, 1.2. No renumeres IDs ya aprobados; los nuevos van al final.
- Usa EARS en español: «CUANDO…, EL DMS DEBE…», «MIENTRAS…, EL DMS DEBE…», «SI…, ENTONCES EL DMS DEBE…», «DONDE…, EL DMS DEBE…».
- Justo después del ID indica el origen: (Origen: ADDW), (Origen: Cliente) o (Origen: SUPUESTO).
- Todo número que no salga de una fuente es SUPUESTO y además se lista en una sección «Preguntas para el cliente».
- Un criterio = un comportamiento verificable, con números y unidades (km/h, s). Prohibido: «inmediato», «rápido», «adecuado», «a tiempo».
- Formato de cada criterio, en una sola línea:
  `- **REQ-01** (Origen: ADDW) MIENTRAS …, CUANDO …, EL DMS DEBE …`

## Diseño (design.md)

- Cada componente o decisión indica qué requisitos cubre, con la línea `Cubre: REQ-01, REQ-02`.
- La lógica de decisión es determinista y está separada del modelo de IA: el modelo estima, la lógica decide.

## Tareas (tasks.md)

- Cada tarea termina con la línea `_Requisitos: REQ-01, REQ-02_`.
- Cada tarea de código trae su tarea de pruebas de valores límite.

## Código

- Donde se implementa un requisito, deja un comentario `# REQ-NN` en esa línea o al inicio del bloque.
- No escribas comportamiento que no salga de un REQ. Si hace falta, primero propone un REQ nuevo en requirements.md.

## Pruebas

- unittest, en archivos `test_*.py`.
- El nombre de cada prueba empieza con su requisito: `test_req01_…`. Si verifica varios, agrega `Verifica: REQ-04, REQ-07` en su docstring.
- Por cada umbral prueba el valor justo debajo y el valor exacto del límite (3.49 s y 3.50 s; 49.9 km/h y 50 km/h).

## Evidencia

- Al terminar cada tarea, ejecuta `python trazabilidad.py`. Si reporta huecos, corrígelos antes de marcar la tarea como completa.
