---
inclusion: always
---

# Producto

Sistema de monitoreo del conductor (DMS) de laboratorio, para una conferencia universitaria. Una cámara y un modelo de IA estiman si el conductor mira fuera del camino o tiene los ojos cerrados; una lógica determinista decide si hay que alertar.

## Fuente normativa

Alerta avanzada de distracción (ADDW) del Reglamento General de Seguridad de la Unión Europea:

- A partir de 20 km/h, con la mirada fuera del camino, la alerta debe llegar a más tardar a los 6 s.
- A partir de 50 km/h, a más tardar a los 3.5 s.
- La alerta es visual, más sonido o vibración, y puede intensificarse.
- Sin identificación biométrica; los datos se quedan en el vehículo.

Cualquier otro umbral es un SUPUESTO que se confirma con el cliente.

## Alcance

- Entradas por cuadro: tiempo en ms, velocidad en km/h, rostro visible, mirada fuera del camino, ojos cerrados.
- Salida: una alerta (ninguna, distracción, somnolencia o monitoreo no disponible).
- Material didáctico: no está validado para uso en un vehículo.
