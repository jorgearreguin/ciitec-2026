# Requisito del cliente

Pega solo esta frase al crear la spec en Kiro, tal como llegó del cliente:

> El sistema debe detectar si el conductor está distraído y avisarle de inmediato.

No agregues números ni aclaraciones: el ejercicio es ver qué preguntas hace Kiro, qué toma de la fuente normativa (product.md) y qué marca como SUPUESTO.
