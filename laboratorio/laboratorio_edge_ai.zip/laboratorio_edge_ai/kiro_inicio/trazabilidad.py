"""Matriz de trazabilidad: requisito -> codigo -> prueba -> resultado.

Uso:
  python trazabilidad.py
  python trazabilidad.py --spec .kiro/specs/dms/requirements.md --raiz . --estricto

Sin --spec busca, en este orden, .kiro/specs/*/requirements.md y referencia/requirements.md.

Que hace:
1. Lee los requisitos REQ-NN de la especificacion (y su origen: ADDW, Cliente, SUPUESTO).
2. Busca en el codigo los comentarios "# REQ-NN" que marcan donde se implementa cada uno.
3. Ejecuta las pruebas unittest (test_*.py) y relaciona cada prueba con su requisito por el
   nombre (test_req01_...) o por "Verifica: REQ-NN" en su docstring.
4. Escribe matriz_trazabilidad.md y matriz_trazabilidad.csv y reporta los huecos: requisitos
   sin codigo, sin prueba, con pruebas que fallan o sin origen; pruebas sin requisito; e IDs
   usados en el codigo o en las pruebas que no existen en la especificacion.

Con --estricto termina con codigo 1 si hay huecos (sirve para un hook o para CI).
Solo usa la biblioteca estandar de Python.
"""
from __future__ import annotations

import argparse
import csv
import datetime
import glob
import io
import os
import re
import sys
import unittest
from contextlib import redirect_stderr, redirect_stdout

RE_ID = re.compile(r"REQ-(\d{2,3})")
RE_DEF = re.compile(r"^\s*(?:[-*]\s*)?\**\s*REQ-(\d{2,3})\b")
RE_PRUEBA = re.compile(r"req[_-]?(\d{2,3})", re.IGNORECASE)
RE_ORIGEN = re.compile(r"\(\s*Origen:\s*([^)]+)\)", re.IGNORECASE)
CARPETAS_IGNORADAS = {".git", ".kiro", "venv", ".venv", "env", "__pycache__", "node_modules", "referencia"}
ESTE_ARCHIVO = os.path.basename(__file__)


def buscar_spec(raiz: str) -> str | None:
    candidatas = sorted(glob.glob(os.path.join(raiz, ".kiro", "specs", "*", "requirements.md")))
    candidatas.append(os.path.join(raiz, "referencia", "requirements.md"))
    for ruta in candidatas:
        if os.path.isfile(ruta):
            return ruta
    return None


def leer_spec(ruta: str) -> dict:
    """Devuelve {REQ-NN: {texto, origen, linea}} con la primera definicion de cada ID."""
    with open(ruta, encoding="utf-8") as f:
        lineas = f.read().splitlines()
    reqs: dict = {}
    hay_definiciones = any(RE_DEF.match(l) for l in lineas)
    for i, linea in enumerate(lineas):
        m = RE_DEF.match(linea) if hay_definiciones else RE_ID.search(linea)
        if not m:
            continue
        rid = "REQ-" + m.group(1)
        if rid in reqs:
            continue
        texto = linea
        j = i + 1
        while j < len(lineas) and lineas[j].startswith(("  ", "\t")) and lineas[j].strip() \
                and not RE_DEF.match(lineas[j]):
            texto += " " + lineas[j].strip()
            j += 1
        origen = RE_ORIGEN.search(texto)
        texto = RE_ORIGEN.sub("", texto)
        texto = re.sub(r"[*_`]", "", texto)
        texto = re.sub(r"^\s*[-*]?\s*REQ-\d+\s*[:.\-]?\s*", "", texto).strip()
        reqs[rid] = {"texto": texto, "origen": origen.group(1).strip() if origen else "", "linea": i + 1}
    return reqs


def buscar_codigo(raiz: str) -> dict:
    """Devuelve {REQ-NN: [(archivo, linea), ...]} a partir de comentarios '# REQ-NN'."""
    usos: dict = {}
    for carpeta, subcarpetas, archivos in os.walk(raiz):
        subcarpetas[:] = [d for d in subcarpetas if d not in CARPETAS_IGNORADAS]
        for nombre in sorted(archivos):
            if not nombre.endswith(".py") or nombre.startswith("test") or nombre == ESTE_ARCHIVO:
                continue
            ruta = os.path.join(carpeta, nombre)
            with open(ruta, encoding="utf-8", errors="replace") as f:
                for n, linea in enumerate(f, 1):
                    if "#" not in linea:
                        continue
                    comentario = linea.split("#", 1)[1]
                    for num in RE_ID.findall(comentario):
                        usos.setdefault("REQ-" + num, []).append((os.path.relpath(ruta, raiz), n))
    return usos


class Registro(unittest.TestResult):
    def __init__(self):
        super().__init__()
        self.estado: dict = {}

    def addSuccess(self, prueba):
        super().addSuccess(prueba)
        self.estado[prueba] = "pasa"

    def addFailure(self, prueba, err):
        super().addFailure(prueba, err)
        self.estado[prueba] = "falla"

    def addError(self, prueba, err):
        super().addError(prueba, err)
        self.estado[prueba] = "error"

    def addSkip(self, prueba, motivo):
        super().addSkip(prueba, motivo)
        self.estado[prueba] = "omitida"

    def addExpectedFailure(self, prueba, err):
        super().addExpectedFailure(prueba, err)
        self.estado[prueba] = "pasa"

    def addUnexpectedSuccess(self, prueba):
        super().addUnexpectedSuccess(prueba)
        self.estado[prueba] = "falla"


def correr_pruebas(raiz: str) -> Registro:
    raiz = os.path.abspath(raiz)
    if raiz not in sys.path:
        sys.path.insert(0, raiz)
    suite = unittest.defaultTestLoader.discover(raiz, pattern="test*.py", top_level_dir=raiz)
    registro = Registro()
    with redirect_stdout(io.StringIO()), redirect_stderr(io.StringIO()):
        suite.run(registro)
    return registro


def reqs_de_prueba(prueba) -> set:
    nombre = getattr(prueba, "_testMethodName", "")
    ids = {"REQ-" + n for n in RE_PRUEBA.findall(nombre)}
    doc = getattr(prueba, "_testMethodDoc", None) or ""
    m = re.search(r"Verifica:\s*(.+)", doc)
    if m:
        ids |= {"REQ-" + n for n in RE_ID.findall(m.group(1))}
    return ids


def agrupar(lugares) -> str:
    por_archivo: dict = {}
    for archivo, linea in lugares:
        por_archivo.setdefault(archivo, []).append(str(linea))
    return "; ".join(f"{a}: {', '.join(ls)}" for a, ls in por_archivo.items())


def main() -> int:
    ap = argparse.ArgumentParser(description="Genera la matriz de trazabilidad del proyecto.")
    ap.add_argument("--raiz", default=os.path.dirname(os.path.abspath(__file__)), help="carpeta del proyecto")
    ap.add_argument("--spec", help="ruta de requirements.md")
    ap.add_argument("--estricto", action="store_true", help="termina con codigo 1 si hay huecos")
    args = ap.parse_args()

    raiz = os.path.abspath(args.raiz)
    spec = args.spec or buscar_spec(raiz)
    if not spec or not os.path.isfile(spec):
        print("No encontre requirements.md. Usa --spec ruta/requirements.md")
        return 2
    reqs = leer_spec(spec)
    if not reqs:
        print(f"{spec} no tiene requisitos con ID REQ-NN.")
        return 2

    codigo = buscar_codigo(raiz)
    registro = correr_pruebas(raiz)

    pruebas_por_req: dict = {r: [] for r in reqs}
    sin_requisito, ids_huerfanos, no_importadas = [], set(), []
    for prueba, estado in registro.estado.items():
        if prueba.__class__.__name__ == "_FailedTest":
            no_importadas.append(prueba.id().split(".")[-1])
            continue
        ids = reqs_de_prueba(prueba)
        if not ids:
            sin_requisito.append((prueba._testMethodName, estado))
        for rid in ids:
            if rid in pruebas_por_req:
                pruebas_por_req[rid].append((prueba._testMethodName, estado))
            else:
                ids_huerfanos.add(f"{rid} (en la prueba {prueba._testMethodName})")
    for rid, lugares in codigo.items():
        if rid not in reqs:
            ids_huerfanos.add(f"{rid} (en {agrupar(lugares)})")

    filas, huecos = [], []
    for rid in sorted(reqs, key=lambda r: int(r.split("-")[1])):
        info = reqs[rid]
        pruebas = pruebas_por_req[rid]
        faltas = []
        if not info["origen"]:
            faltas.append("sin origen")
        if rid not in codigo:
            faltas.append("sin código")
        if not pruebas:
            faltas.append("sin prueba")
        malas = [n for n, e in pruebas if e != "pasa"]
        if malas:
            faltas.append(f"{len(malas)} prueba(s) no pasan")
        resultado = f"{len(pruebas) - len(malas)}/{len(pruebas)} pasan" if pruebas else "—"
        estado = "Completo" if not faltas else "Hueco: " + ", ".join(faltas)
        if faltas:
            huecos.append(f"{rid}: {', '.join(faltas)}")
        filas.append({
            "requisito": rid, "origen": info["origen"] or "—", "texto": info["texto"],
            "codigo": agrupar(codigo.get(rid, [])) or "—", "pruebas": len(pruebas),
            "resultado": resultado, "estado": estado,
        })
    if sin_requisito:
        huecos.append(f"{len(sin_requisito)} prueba(s) sin requisito")
    if ids_huerfanos:
        huecos.append(f"{len(ids_huerfanos)} ID(s) que no existen en la especificación")
    if no_importadas:
        huecos.append(f"no se pudieron importar: {', '.join(no_importadas)}")

    total = len(registro.estado)
    pasan = sum(1 for e in registro.estado.values() if e == "pasa")
    ahora = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
    spec_rel = os.path.relpath(spec, raiz)

    md = [f"# Matriz de trazabilidad", "",
          f"Especificación: `{spec_rel}` · Generada: {ahora} · Pruebas: {pasan} de {total} pasan", "",
          "Cadena: regla → requisito (REQ-NN) → código (`# REQ-NN`) → prueba (`test_reqNN_…`) → resultado.", "",
          "| Requisito | Origen | Qué exige | Código | Pruebas | Resultado | Estado |",
          "| --- | --- | --- | --- | --- | --- | --- |"]
    for f in filas:
        texto = f["texto"].replace("|", "\\|")
        md.append(f"| {f['requisito']} | {f['origen']} | {texto} | {f['codigo']} | {f['pruebas']} | "
                  f"{f['resultado']} | {f['estado']} |")
    md += ["", "## Huecos", ""]
    md += [f"- {h}" for h in huecos] if huecos else ["- Ninguno: cada requisito tiene origen, código y pruebas que pasan."]
    if sin_requisito:
        md += ["", "## Pruebas sin requisito", ""]
        md += [f"- `{n}` ({e}): agrega su REQ a la especificación o documenta por qué no lo necesita." for n, e in sin_requisito]
    if ids_huerfanos:
        md += ["", "## IDs que no existen en la especificación", ""]
        md += [f"- {h}" for h in sorted(ids_huerfanos)]
    md += ["", "## Detalle de pruebas por requisito", ""]
    for rid in sorted(pruebas_por_req, key=lambda r: int(r.split("-")[1])):
        md.append(f"**{rid}**")
        md.append("")
        md += [f"- `{n}`: {e}" for n, e in pruebas_por_req[rid]] or ["- (sin pruebas)"]
        md.append("")

    salida_md = os.path.join(raiz, "matriz_trazabilidad.md")
    with open(salida_md, "w", encoding="utf-8") as f:
        f.write("\n".join(md) + "\n")
    salida_csv = os.path.join(raiz, "matriz_trazabilidad.csv")
    with open(salida_csv, "w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(filas[0].keys()))
        w.writeheader()
        w.writerows(filas)

    print(f"Especificación: {spec_rel} · {len(reqs)} requisitos · pruebas: {pasan} de {total} pasan")
    for f in filas:
        print(f"  {f['requisito']}  {f['resultado']:>12}  {f['estado']}")
    if huecos:
        print("Huecos:")
        for h in huecos:
            print("  - " + h)
    else:
        print("Sin huecos.")
    print(f"Escribí {os.path.relpath(salida_md, raiz)} y {os.path.relpath(salida_csv, raiz)}")
    return 1 if (args.estricto and huecos) else 0


if __name__ == "__main__":
    sys.exit(main())
